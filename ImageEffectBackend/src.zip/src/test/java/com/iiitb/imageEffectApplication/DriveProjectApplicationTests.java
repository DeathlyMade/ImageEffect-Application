package com.iiitb.imageEffectApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class imageEffectApplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
