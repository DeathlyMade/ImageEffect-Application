package com.iiitb.imageEffectApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageEffectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageEffectApplication.class, args);
	}

}
