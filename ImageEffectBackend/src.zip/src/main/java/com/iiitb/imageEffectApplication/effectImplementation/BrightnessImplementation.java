package com.iiitb.imageEffectApplication.effectImplementation;
import com.iiitb.imageEffectApplication.baseEffects.SingleValueParameterizableEffect;
import com.iiitb.imageEffectApplication.exception.IllegalParameterException;
import com.iiitb.imageEffectApplication.service.LoggingService;
import com.iiitb.imageEffectApplication.libraryInterfaces.Pixel;
import com.iiitb.imageEffectApplication.libraryInterfaces.BrightnessInterface;

public class BrightnessImplementation implements SingleValueParameterizableEffect{
    private float amount=0.0f;
    public Pixel[][] apply(Pixel [][] image, String fileName, LoggingService lservice)
    {
        lservice.addLog(fileName, "Brightness", String.valueOf(amount));
        return BrightnessInterface.applyBrightness(image,amount);
    }
    public void setParameterValue(float parameterValue) throws IllegalParameterException
    {
        try{
            if(parameterValue>=0.0 && parameterValue<=200.0)
            {
                amount=parameterValue;
            }
            else {
                throw new IllegalParameterException();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}