package com.iiitb.imageEffectApplication.effectImplementation;
import com.iiitb.imageEffectApplication.baseEffects.DiscreteEffect;
import com.iiitb.imageEffectApplication.exception.IllegalParameterException;
import com.iiitb.imageEffectApplication.service.LoggingService;
import com.iiitb.imageEffectApplication.libraryInterfaces.Pixel;
import com.iiitb.imageEffectApplication.libraryInterfaces.FlipInterface;

public class FlipImplementation implements DiscreteEffect{
    private int hzflipval=0, vertflipval=0;
    public Pixel[][] apply(Pixel [][] image, String fileName, LoggingService lservice)
    {
        if(hzflipval==0 && vertflipval==1)
        {
            lservice.addLog(fileName, "Flip", "Vertical Flip");
        }
        else if(hzflipval==1 && vertflipval==0)
        {
            lservice.addLog(fileName, "Flip", "Horizontal Flip");
        }
        else if(hzflipval==1 && vertflipval==1)
        {
            lservice.addLog(fileName, "Flip", "Vertical and Horizontal Flip");
        }
        else
        {
            lservice.addLog(fileName, "Flip", "No Flip");
        }
        return FlipInterface.applyFlip(image,hzflipval,vertflipval);
    }
    public void selectOptionValue(String optname,int v) throws IllegalParameterException
    {
        try{
            if(optname.equals("Horizontal") && (v==0 || v==1))
            {
                hzflipval=v;
            }
            else if (optname.equals("Vertical") && (v==0 || v==1))
            {
                vertflipval=v;
            }
            else {
                throw new IllegalParameterException();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}