package com.iiitb.imageEffectApplication.effectImplementation;
import com.iiitb.imageEffectApplication.baseEffects.SingleValueDiscreteEffect;
import com.iiitb.imageEffectApplication.exception.IllegalParameterException;
import com.iiitb.imageEffectApplication.service.LoggingService;
import com.iiitb.imageEffectApplication.libraryInterfaces.Pixel;
import com.iiitb.imageEffectApplication.libraryInterfaces.RotationInterface;

public class RotationImplementation implements SingleValueDiscreteEffect{
    private int value=0;
    public Pixel[][] apply(Pixel [][] image, String fileName, LoggingService lservice)
    {
        lservice.addLog(fileName, "Rotation", String.valueOf(value));
        return RotationInterface.applyRotation(image,value);
    }
    public void setParameterValue(int parameterValue) throws IllegalParameterException
    {
        try{
            if(parameterValue==1 || parameterValue==2 || parameterValue==3 || parameterValue==0)
            {
                value=90*parameterValue;
            }
            else {
                throw new IllegalParameterException();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}