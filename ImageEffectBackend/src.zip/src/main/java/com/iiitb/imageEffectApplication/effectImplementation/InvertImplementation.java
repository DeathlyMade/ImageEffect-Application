package com.iiitb.imageEffectApplication.effectImplementation;
import com.iiitb.imageEffectApplication.baseEffects.PhotoEffect;
import com.iiitb.imageEffectApplication.service.LoggingService;
import com.iiitb.imageEffectApplication.libraryInterfaces.Pixel;
import com.iiitb.imageEffectApplication.libraryInterfaces.InvertInterface;

public class InvertImplementation implements PhotoEffect{
    public Pixel[][] apply(Pixel [][] image, String fileName, LoggingService lservice)
    {
        lservice.addLog(fileName, "Invert", "Executed");
        return InvertInterface.applyInvert(image);
    }
}