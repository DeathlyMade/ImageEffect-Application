package com.iiitb.imageEffectApplication.effectImplementation;
import com.iiitb.imageEffectApplication.baseEffects.PhotoEffect;
import com.iiitb.imageEffectApplication.service.LoggingService;
import com.iiitb.imageEffectApplication.libraryInterfaces.Pixel;
import com.iiitb.imageEffectApplication.libraryInterfaces.GrayscaleInterface;

public class GrayscaleImplementation implements PhotoEffect{
    public Pixel[][] apply(Pixel [][] image, String fileName, LoggingService lservice)
    {
        lservice.addLog(fileName, "GrayScale", "Executed");
        return GrayscaleInterface.applyGrayscale(image);
    }
}