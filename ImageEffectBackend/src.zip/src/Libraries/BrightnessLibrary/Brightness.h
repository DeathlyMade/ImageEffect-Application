#include <vector>

using namespace std;

#ifndef BRIGHTNESS_H
#define BRIGHTNESS_H
#include "../Pixel.h"

vector<vector<Pixel>> alterImageBrightness(vector<vector<Pixel>> image, float amt);

#endif