#ifndef SHARPEN_H
#define SHARPEN_H
#include "../Pixel.h"

#endif