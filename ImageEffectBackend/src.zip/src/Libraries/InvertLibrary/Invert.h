#ifndef INVERT_H
#define INVERT_H
#include "../Pixel.h"
#include "vector"
using namespace std;

vector< vector< Pixel>> applyInvert(vector< vector< Pixel>> imageVector);

#endif