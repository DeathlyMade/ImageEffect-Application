#include <vector>

using namespace std;

#ifndef CONTRAST_H
#define CONTRAST_H
#include "../Pixel.h"

vector<vector<Pixel>> alterImageContrast(vector<vector<Pixel>> image, float amt);

#endif