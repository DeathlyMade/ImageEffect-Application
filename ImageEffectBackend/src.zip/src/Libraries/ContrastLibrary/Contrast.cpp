#include <vector>
#include "Contrast.h"

using namespace std;

int truncate(int val, int k) {
    if (val >= k) {
        return k;
    }
    else if (val <= 0) {
        return 0;
    }
    else {
        return val;
    }
}

vector<vector<Pixel>> alterImageContrast(vector<vector<Pixel>> image, float amt) {
    // constructing a new image
    vector<vector<Pixel>> newImage;
    // changing the range of amt from 0;200 to -1;1
    amt = -1+(amt/100.0);
    for (vector<Pixel> row: image) {
        vector<Pixel> newRow;
        for (Pixel pixel: row) {
            // getting the HSL pixel from the RGB pixel
            Pixel newPixel;

            // adjusted value of contrast change that ranges from -128 to 128
            int c = int(128*amt);

            // (this is the portion of the code where the contrast is changed)
            float factor = (259*(c+255)/255*(259-c));
            newPixel.r = truncate(int(factor*(pixel.r-128) + 128), 255);
            newPixel.g = truncate(int(factor*(pixel.g-128) + 128), 255);
            newPixel.b = truncate(int(factor*(pixel.b-128) + 128), 255);

            // adding it into the new image
            newRow.push_back(newPixel);
        }
        newImage.push_back(newRow);
    }

    return newImage;
}