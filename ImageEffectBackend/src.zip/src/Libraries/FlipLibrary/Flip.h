#include <vector>

using namespace std;

#ifndef FLIP_H
#define FLIP_H
#include "../Pixel.h"

vector<vector<Pixel>> flipImage(vector<vector<Pixel>> image, int hFlip, int vFlip);

#endif