#include <vector>
#include "Grayscale.h"

#define MAX(a, b) a > b ? a : b
#define MIN(a, b) a < b ? a : b

using namespace std;

// a function that takes in an RGB pixel with integer value range of (0, 255)
// and returns an HSL pixel with the same value range
Pixel RGBtoHSL(Pixel pixel) {
    // minimum, maximum and range of RGB values of the pixel
    int min = MIN(MIN(pixel.r, pixel.g), pixel.b);
    int max = MAX(MAX(pixel.r, pixel.g), pixel.b);
    int delta = max-min;

    // transforming the pixel into HSL (Hue, Saturation, Light) values,
    // whose values range from 0 to 1
    float h, s, l;

    l = (max+min)/2.0;
    if (delta == 0) {
        h = 0;
        s = 0;
    }
    else {
        if (l < 0.5) {
            s = delta/(min+max);
        }
        else {
            s = delta/(2-min-max);
        }

        float delR = (((max-pixel.r)/6.0) + (delta/2.0)) / (delta);
        float delG = (((max-pixel.g)/6.0) + (delta/2.0)) / (delta);
        float delB = (((max-pixel.b)/6.0) + (delta/2.0)) / (delta);

        if (max == pixel.r) {
            h = delB-delG;
        }
        else if (max == pixel.g) {
            h = (1/3.0) + delR-delB;
        }
        else {
            h = (2/3.0) + delG-delR;
        }
        if (h < 0) {
            h++;
        }
        else if (h > 1) {
            h--;
        }
    }

    return Pixel{int(h*255), int(s*255), int(l*255)};
}

// a function used in converting HSL to RGB
float hueToRGB(float v1, float v2, float vH) {
    if (vH < 0) {
        vH++;
    }
    else if (vH > 1) {
        vH--;
    }
    if ((6*vH) < 1) {
        return (v1 + 6*(v2-v1)*vH);
    }
    if ((2*vH) < 1) {
        return v2;
    }
    if ((3*vH) < 1) {
        return (v1 + 6*(v2-v1)*(2/3.0 - vH));
    }
    return v1;
}

// a function that takes in an HSL pixel with integer value range of (0, 255)
// and returns an RGB pixel with the same value range
Pixel HSLtoRGB(Pixel pixel) {
    int r, g, b;
    float h, s, l, v1, v2;
    h = float(pixel.b)/255.0;
    s = float(pixel.b)/255.0;
    l = float(pixel.b)/255.0;

    if (s == 0) {
        r = int(l*255);
        g = int(l*255);
        b = int(l*255);
    }
    else {
        if (l < 0.5) {
            v2 = l*(1+s);
        }
        else {
            v2 = (l+s) - (s*l);
        }
        v1 = 2*l - v2;

        r = int(255 * hueToRGB(v1, v2, h+(1/3.0)));
        g = int(255 * hueToRGB(v1, v2, h));
        b = int(255 * hueToRGB(v1, v2, h-(1/3.0)));
    }
    return Pixel{r, g, b};
}

vector<vector<Pixel>> grayScaleImage(vector<vector<Pixel>> image) {
    // constructing a new image
    vector<vector<Pixel>> newImage;

    int i = 0;

    for (vector<Pixel> row: image) {
        vector<Pixel> newRow;
        for (Pixel pixel: row) {
            // getting the HSL pixel from the RGB pixel
            Pixel newPixel = RGBtoHSL(pixel);

            // setting the H and S values of the new HSL pixel to get a
            // purely gray image
            // (this is the portion of the code where the grayscale effect
            // is applied)
            newPixel.r = 0;
            newPixel.g = 0;

            // transforming the HSL pixel back into RGB
            newPixel = HSLtoRGB(newPixel);

            // adding it into the new image
            newRow.push_back(newPixel);
        }
        newImage.push_back(newRow);
    }

    return newImage;
}